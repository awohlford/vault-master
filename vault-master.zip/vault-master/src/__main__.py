from . import vault

if __name__ == '__main__':
    vault.main()
